[https://plusch011.github.io/rsschool-2019Q1-cv/cv](https://plusch011.github.io/rsschool-2019Q1-cv/cv)
