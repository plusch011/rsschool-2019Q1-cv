Resume
1. Uladzislau Pauliushchyk
2. +375 29 358 95 45 plusch321@mail.ru
3. Summary: i enjoy styding JS, and i want to be pro at this.
4. Skills: JS CSS HTML Git
5. https://github.com/plusch011/sudoku
6. Junior: Web Programming courses (learning);
7. Average, learning JS CSS HTML
8. A2+ at EPAM site test